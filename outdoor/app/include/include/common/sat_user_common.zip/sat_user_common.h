

#ifndef _SAT_USER_COMMON_H_
#define _SAT_USER_COMMON_H_
#include <netinet/in.h>

#include "ssd20x_common.h"

#define NETWORK_ETH_NAME		"eth0"

/*
 * @日期: 2022-08-06
 * @作者: leo.liu
 * @功能: 获取线程栈内存大小
 * @return:
 */
pthread_attr_t * sat_pthread_attr_get(void);
/***********************************************
** 作者: leo.liu
** 日期: 2022-12-26 16:48:12
** 说明: 获取编译日期
***********************************************/
bool platform_build_date_get(struct tm *tm);
/***********************************************
** 作者: leo.liu
** 日期: 2022-12-26 16:48:12
** 说明: sip账号获取其IP和房号
***********************************************/
bool sip_user_get_number_and_ip(const char *user, char *ip, char *number);
/****************************************************************
**@日期: 2022-09-28
**@作者: leo.liu
**@功能:获取文件大小
*****************************************************************/
size_t sat_file_size_get(const char * path);

/****************************************************************
**@日期: 2022-09-28
**@作者: leo.liu
**@功能:读取文件
**@ data
*****************************************************************/
size_t sat_file_read(const char * path, char * data, size_t size);

/***********************************************
** 作者: leo.liu
** 日期: 2022-11-21 10:29:2
** 说明: 读取本机的UUID 
***********************************************/
char * platform_read_device_uuid(void);

/***********************************************
** 作者: leo.liu
** 日期: 2022-11-26 10:45:38
** 说明: 获取linphone sip账号 
***********************************************/
bool sat_sip_local_user_get(char * user);

/***********************************************
** 作者: leo.liu
** 日期: 2022-11-26 9:49:0
** 说明: 获取网卡的Ip 
***********************************************/
bool sat_ip_mac_addres_get(const char * eth, char * ip, char * mac);

/***********************************************
** 作者: leo.liu
** 日期: 2022-11-26 11:25:54
** 说明: udhchc 获取IP 
***********************************************/
void sat_network_udhcpc_ip(const char * eth);

/***********************************************
** 作者: leo.liu
** 日期: 2022-11-26 11:26:51
** 说明: 写入mac 
***********************************************/
bool sat_network_eth0_mac_write(const char * mac);

/***********************************************
** 作者: leo.liu
** 日期: 2022-11-26 11:26:51
** 说明: 写入mac 
***********************************************/
bool sat_network_eth1_mac_write(const char * mac);

/***********************************************
** 作者: leo.liu
** 日期: 2022-11-28 10:6:44
** 说明: 开启和关闭网络 
***********************************************/
void sat_network_enable(const char * eth, bool en);

/****************************************************************
**@日期: 2022-09-16
**@作者: leo.liu
**@功能:关闭
*****************************************************************/
bool sat_socket_close(int socket_fd);

/***********************************************
** 作者: leo.liu
** 日期: 2023-1-5 16:15:12
** 说明: 创建套接字，并且接入组播ip 
***********************************************/
bool sat_socket_multicast_join(int socket_fd, const char * multicast_ip);

/***********************************************
** 作者: leo.liu
** 日期: 2023-1-6 8:37:33
** 说明: tcp server open 
***********************************************/
bool sat_socket_tcp_open(int * fd, int port, int max_client);

/***********************************************
** 作者: leo.liu
** 日期: 2023-1-6 9:8:19
** 说明: server fd 同意连接 
***********************************************/
int sat_socket_tcp_accept(int server_fd, struct sockaddr_in * client_addr, unsigned int timeout_ms);

/***********************************************
** 作者: leo.liu
** 日期: 2023-1-7 10:1:24
** 说明: 连接服务器 
***********************************************/
bool sat_socket_tcp_connect(int socket_fd, const char * server_ip, int port, unsigned int wait_ms);

/***********************************************
** 作者: leo.liu
** 日期: 2023-1-6 9:8:19
** 说明: server fd 接收数据
***********************************************/
int sat_socket_tcp_receive(int client_fd, unsigned char * data, int data_len, int timeout_ms);

/***********************************************
** 作者: leo.liu
** 日期: 2023-1-7 9:46:26
** 说明: tcp 发送数据 
***********************************************/
bool sat_socket_tcp_send(int socket_fd, unsigned char * data, int data_len, unsigned int timeout_ms);

/***********************************************
** 作者: leo.liu
** 日期: 2023-1-9 13:39:14
** 说明: UDP打开套接字 
***********************************************/
bool sat_socket_udp_open(int * socket_fd, int port, bool broadcast);

/****************************************************************
**@日期: 2022-09-16
**@作者: leo.liu
**@功能:发送探测消息
*****************************************************************/
bool sat_socket_udp_send(int socket_fd, const char * data, size_t data_len, const char * ip, int port, int timeout_ms);

/****************************************************************
**@日期: 2022-09-20
**@作者: leo.liu
**@功能:接受一个消息
*****************************************************************/
int sat_socket_udp_receive(int socket_fd, char * data, size_t data_len, struct sockaddr_in * client_addr, int timeout_ms);

#endif

