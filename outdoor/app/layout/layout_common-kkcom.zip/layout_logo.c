#include "layout_define.h"
enum
{
  layout_logo_obj_id_full_view,
  layout_logo_obj_id_row_cont,

};
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @注释: 用于保存文件
 */
#define JPG_FILE_TOTAL 128
static char *jpg_file_buffer[JPG_FILE_TOTAL] = {NULL};
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @注释: jpg扫描到文件总数
 */
static int jpg_file_total = 0;
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 初始化buffer
 * @return:
 */
static void sd_jpg_file_buffer_init(void)
{
  if (jpg_file_total == 0)
  {
    memset(jpg_file_buffer, 0, sizeof(jpg_file_buffer));
    return;
  }
  jpg_file_total = 0;
  for (int i = 0; i < JPG_FILE_TOTAL; i++)
  {
    if (jpg_file_buffer[i] != NULL)
    {
      free(jpg_file_buffer[i]);
      jpg_file_buffer[i] = NULL;
    }
  }
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 将文件加入到buffer中
 * @return:
 */
static bool jpg_file_find_push_node(char *name)
{
  if (jpg_file_total >= JPG_FILE_TOTAL)
  {
    return false;
  }
  char *file = strrchr(name, '/') + 1;
  int string_lenth = strlen(name) - 1;
  name[string_lenth] = '\0';
  jpg_file_buffer[jpg_file_total] = malloc(string_lenth + 1);
  strcpy(jpg_file_buffer[jpg_file_total], file);
  LV_LOG_USER("%s", jpg_file_buffer[jpg_file_total]);
  jpg_file_total++;
  return true;
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liujpg_file_buffer[0]
 * @功能: 扫描根目录下的jpg文件
 * @return:
 */
static void layout_sd_jpg_file_scanf(void)
{
  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: 初始化jpg buffer
   */
  sd_jpg_file_buffer_init();

  char name[128] = {0};
  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: jpg
   */
  FILE *fp = popen("find " SD_BASE_PATH " -iname \"*.jpg\"", "r");
  while (memset(name, 0, sizeof(name)), fgets(name, sizeof(name) - 1, fp) > 0)
  {
    jpg_file_find_push_node(name);
  }
  pclose(fp);

  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: JPG
   */
  fp = popen("find " SD_BASE_PATH " -iname \"*.jpeg\"", "r");
  while (memset(name, 0, sizeof(name)), fgets(name, sizeof(name) - 1, fp) > 0)
  {
    jpg_file_find_push_node(name);
  }
  pclose(fp);
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: sd状态被修改的执行的回调函数
 * @return:
 */
static void layout_sd_chanage_func(void)
{

  sat_layout_goto(sat_playout_get(logo));
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 获取当前预览的index
 * @return:
 */
int jpg_file_index_get(void)
{
  lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), layout_logo_obj_id_full_view);
  if (obj == NULL)
  {
    LV_LOG_ERROR("get child id failed (%d)", layout_logo_obj_id_full_view);
    return -1;
  }
  return *((int *)(obj->user_data));
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 按钮点击
 * @return:
 */
static void logo_full_imgbtn_up(lv_event_t *event)
{
  lv_obj_t *row_cont = lv_obj_get_child_form_id(lv_scr_act(), layout_logo_obj_id_row_cont);
  if (lv_obj_has_flag_any(row_cont, LV_OBJ_FLAG_HIDDEN) == true)
  {
    lv_obj_clear_flag(row_cont, LV_OBJ_FLAG_HIDDEN);
  }
  else
  {
    lv_obj_add_flag(row_cont, LV_OBJ_FLAG_HIDDEN);
  }
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 显示图片控件
 * @return:
 */
static void logo_full_imgbtn_create(void)
{
  lv_obj_t *obj = lv_img_create(lv_scr_act());
  lv_obj_set_id(obj, layout_logo_obj_id_full_view);
  lv_obj_set_pos(obj, 0, 0);
  lv_obj_set_size(obj, 1024, 600);
  lv_obj_set_style_bg_color(obj, lv_color_hex(0x00), LV_STATE_DEFAULT);
  void *src = file_path_src_get("A:" SD_BASE_PATH "/", jpg_file_buffer[0], 1024, 600);
  lv_img_set_src(obj, src);
  static int jpg_file_index = 0;
  jpg_file_index = 0;
  obj->user_data = &jpg_file_index;

  lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_add_event_cb(obj, logo_full_imgbtn_up, LV_EVENT_CLICKED, NULL);

}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 缩略图点击
 * @return:
 */
static void logo_thumb_obj_up(lv_event_t *event)
{
  lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), layout_logo_obj_id_full_view);
  lv_img_cache_invalidate_src(lv_img_get_src(obj));

  lv_img_set_src(obj, file_path_src_get(NULL, lv_img_get_src(lv_event_get_current_target(event)), 1024, 600));
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 创建预览小图
 * @return:
 */
static void logo_thumb_obj_create(void)
{
  lv_obj_t *parent = lv_obj_get_child_form_id(lv_scr_act(), layout_logo_obj_id_row_cont);
  for (int i = 0; i < jpg_file_total; i++)
  {
    lv_obj_t *img = lv_img_create(parent);
    lv_obj_set_size(img, 300, 200);
    lv_img_set_src(img, file_path_src_get("A:" SD_BASE_PATH "/", jpg_file_buffer[i], 300, 200));
    lv_obj_add_flag(img, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(img, logo_thumb_obj_up, LV_EVENT_CLICKED, NULL);
  }
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 创建底部预览容器
 * @return:
 */
static void logo_thumb_cont_row_create(void)
{
  if (jpg_file_total < 1)
  {
    return;
  }

  lv_obj_t *cont_row = lv_obj_create(lv_scr_act());
  lv_obj_set_id(cont_row, layout_logo_obj_id_row_cont);
  lv_obj_set_pos(cont_row, 724, 0);
  lv_obj_set_size(cont_row, 300, 600);
  lv_obj_set_style_bg_opa(cont_row, LV_OPA_TRANSP, LV_STATE_DEFAULT);
  lv_obj_align(cont_row, LV_ALIGN_TOP_RIGHT, 0, 0);
  lv_obj_set_flex_flow(cont_row, LV_FLEX_FLOW_COLUMN);
  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: 创建预览小图
   */
  logo_thumb_obj_create();
}
static void sat_layout_enter(logo)
{
  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: 扫描jpg文件
   */
  layout_sd_jpg_file_scanf();
  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: 注册sd状态改变函数
   */
  sd_state_channge_callback_register(layout_sd_chanage_func);
  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: 如果sd卡未插入则不执行后面
   */
  if ((media_sdcard_insert_check() == false) || (jpg_file_total < 1))
  {
    return;
  }
  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: 创建全屏预览的控件
   */
  logo_full_imgbtn_create();
  /*
   * @日期: 2022-08-12
   * @作者: leo.liu
   * @注释: 创建顶部预览小图片容器
   */
  logo_thumb_cont_row_create();
}

static void sat_layout_quit(logo)
{
}
sat_layout_create(logo);