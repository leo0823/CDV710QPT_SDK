#include <stdlib.h>
#include "lvgl.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>
#include <mqueue.h>
#include <ctype.h>

#include "common/ssd20x_common.h"
#include "common/sat_main_event.h"
#include "layout_define.h"
/*
 * @日期: 2022-08-06
 * @作者: leo.liu
 * @功能: lvgl 心跳任务
 * @return:
 */
static void *lv_sys_tick_task(void *arg)
{
	struct timeval tv1, tv2;
	gettimeofday(&tv2, NULL);

	while (1)
	{
		gettimeofday(&tv1, NULL);
		lv_tick_inc(tv1.tv_sec * 1000 + tv1.tv_usec / 1000 - tv2.tv_sec * 1000 - tv2.tv_usec / 1000);
		gettimeofday(&tv2, NULL);
		usleep(1000);
	}

	return NULL;
}

/***
** 日期: 2022-04-25 14:22
** 作者: leo.liu
** 函数作用：lvgl的任务调度以及心跳包线程
** 返回参数说明：
***/
static void lv_task_scheduling_start(void)
{
	pthread_t task_id;

	sat_layout_goto(sat_playout_get(logo));
	pthread_create(&task_id, sat_pthread_attr_get(), lv_sys_tick_task, NULL);
	while (1)
	{
		lv_task_handler();
		usleep(1000);
	}
}
/*
 * @日期: 2022-08-06
 * @作者: leo.liu
 * @功能: 主函数入口
 * @return:
 */
int main(int argc, char *argv[])
{
	/*
	 * @日期: 2022-08-06
	 * @作者: leo.liu
	 * @注释: 平台sdk初始化
	 */
	platform_sdk_init();
	/*lv_task_handler
	 * @日期: 2022-08-08
	 * @作者: leo.liu
	 * @注释: lvgl core初始化
	 */
	lv_init();
	/*
	 * @日期: 2022-08-08
	 * @作者: leo.liu
	 * @注释:注册显示设备
	 */
	lv_port_disp_init();
	/*
	 * @日期: 2022-08-08
	 * @作者: leo.liu
	 * @注释: 注册输入设备
	 */
	lv_port_indev_init();
	/*
	 * @日期: 2022-08-08
	 * @作者: leo.liu
	 * @注释: 主任务初始化
	 */
	sat_mian_task_init();
	/*
	 * @日期: 2022-08-11
	 * @作者: leo.liu
	 * @注释: 开启文件系统
	 */
	media_file_list_init();
	/*
	 * @日期: 2022-08-08
	 * @作者: leo.liu
	 * @注释: 开启任务调度
	 */
	lv_task_scheduling_start();
	return 0;
}
