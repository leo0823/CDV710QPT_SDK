#ifndef _LAYOUT_DEFIEN_H_
#define _LAYOUT_DEFIEN_H_
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "lvgl.h"
#include "common/sat_main_event.h"
#include "common/sat_user_file.h"
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 获取ui资源的路径
 * @return:
 */
void *resource_ui_src_get(char *file, uint32_t w, uint32_t h);
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 获取背景图片
 * @return:
 */
void *resource_wallpaper_src_get(char *file, uint32_t w, uint32_t h);
/*
* @日期: 2022-08-12
* @作者: leo.liu
* @功能: 文件路径获取
* @return: 
*/
void* file_path_src_get(char* path,const char* file,uint32_t w,uint32_t h);
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 创建一个ui资源文件
 * @return:
 */
void *resource_ui_src_alloc(char *file, uint32_t w, uint32_t h);
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 创建一个壁纸资源文件
 * @return:
 */
void *resource_wallpaper_src_alloc(char *file, uint32_t w, uint32_t h);
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 释放文件
 * @return:
 */
bool resouce_file_src_free(void *pstr);
/*
 * @日期: 2022-08-08
 * @作者: leo.liu
 * @注释: 定义layout
 */
sat_layout_define(logo);
#endif