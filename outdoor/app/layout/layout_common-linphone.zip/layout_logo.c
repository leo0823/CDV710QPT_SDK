#include "layout_define.h"
#include "onvif.h"
enum
{
        logo_obj_id_call_btn,
        logo_obj_id_answer_btn,
        logo_obj_id_snap_btn,
        logo_obj_id_rec_btn,
        logo_obj_id_search_btn,
        logo_obj_id_ipcamera_info_lable,
        logo_obj_id_stop_ipc_btn,
};
/*
 * @日期: 2022-08-20
 * @作者: leo.liu
 * @功能: call点击事件
 * @return:
 */
static void logo_sip_call_btn_click(lv_event_t *e)
{
        // sat_linphone_call("leo_id2@sip.linphone.org",true,true);
        // sat_linphone_call("11546@192.168.170.104", true, true);
    //    sat_linphone_call("OnePlus8@192.168.170.102", true, true);
    sat_linphone_call("7001010040@192.168.170.2", true, true);
}

/*
 * @日期: 2022-08-20
 * @作者: leo.liu
 * @功能: 创建call 按钮
 * @return:
 */
static lv_obj_t *logo_sip_call_btn_create(void)
{
        lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), logo_obj_id_call_btn);
        if (obj != NULL)
        {
                return obj;
        }

        obj = lv_label_create(lv_scr_act());
        lv_obj_set_id(obj, logo_obj_id_call_btn);
        lv_obj_set_pos(obj, 100, 100);
        lv_obj_set_size(obj, 100, 100);
        lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
        /*
         * @日期: 2022-08-20
         * @作者: leo.liu
         * @注释: 设置风格
         */
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFFFFFF), LV_STATE_DEFAULT);
        lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, LV_STATE_DEFAULT);

        lv_label_set_text(obj, "call");
        lv_obj_set_style_text_color(obj, lv_color_hex(0x00), LV_STATE_DEFAULT);
        lv_obj_set_style_text_align(obj, LV_TEXT_ALIGN_CENTER, LV_STATE_DEFAULT);

        lv_obj_add_event_cb(obj, logo_sip_call_btn_click, LV_EVENT_CLICKED, NULL);
        return obj;
}

static void logo_sip_answer_btn_click(lv_event_t *e)
{
        sat_linphone_answer(-1);
}

/*
 * @日期: 2022-08-20
 * @作者: leo.liu
 * @功能: 创建call 按钮
 * @return:
 */
static lv_obj_t *logo_sip_answer_btn_create(void)
{
        lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), logo_obj_id_answer_btn);
        if (obj != NULL)
        {
                return obj;
        }

        obj = lv_label_create(lv_scr_act());
        lv_obj_set_id(obj, logo_obj_id_answer_btn);
        lv_obj_set_pos(obj, 250, 100);
        lv_obj_set_size(obj, 100, 100);
        lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
        /*
         * @日期: 2022-08-20
         * @作者: leo.liu
         * @注释: 设置风格
         */
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFFFFFF), LV_STATE_DEFAULT);
        lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, LV_STATE_DEFAULT);

        lv_label_set_text(obj, "answer");
        lv_obj_set_style_text_color(obj, lv_color_hex(0x00), LV_STATE_DEFAULT);
        lv_obj_set_style_text_align(obj, LV_TEXT_ALIGN_CENTER, LV_STATE_DEFAULT);

        lv_obj_add_event_cb(obj, logo_sip_answer_btn_click, LV_EVENT_CLICKED, NULL);
        return obj;
}

static void logo_sip_snap_btn_click(lv_event_t *e)
{
        record_jpeg_start(REC_MODE_MANUAL);
}

/*
 * @日期: 2022-08-20
 * @作者: leo.liu
 * @功能: 创建snap 按钮
 * @return:
 */
static lv_obj_t *logo_sip_snap_btn_create(void)
{
        lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), logo_obj_id_snap_btn);
        if (obj != NULL)
        {
                return obj;
        }

        obj = lv_label_create(lv_scr_act());
        lv_obj_set_id(obj, logo_obj_id_snap_btn);
        lv_obj_set_pos(obj, 400, 100);
        lv_obj_set_size(obj, 100, 100);
        lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
        /*
         * @日期: 2022-08-20
         * @作者: leo.liu
         * @注释: 设置风格
         */
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFFFFFF), LV_STATE_DEFAULT);
        lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, LV_STATE_DEFAULT);

        lv_label_set_text(obj, "snap");
        lv_obj_set_style_text_color(obj, lv_color_hex(0x00), LV_STATE_DEFAULT);
        lv_obj_set_style_text_align(obj, LV_TEXT_ALIGN_CENTER, LV_STATE_DEFAULT);

        lv_obj_add_event_cb(obj, logo_sip_snap_btn_click, LV_EVENT_CLICKED, NULL);
        return obj;
}
static void logo_snap_state_display(bool ready)
{
        printf("==================%s \n", ready ? "snapshot start" : "snapshot finish");
        lv_obj_t *snap_obj = logo_sip_snap_btn_create();
        lv_obj_set_style_bg_color(snap_obj, ready ? lv_color_hex(0x0000FF) : lv_color_hex(0xFFFFF), LV_STATE_DEFAULT);
}

static void logo_sip_record_btn_click(lv_event_t *e)
{
        lv_state_t state = lv_obj_get_state(e->target);
        if (state & LV_STATE_USER_1)
        {
                record_video_stop();
        }
        else
        {
                record_video_start(true, REC_MODE_MANUAL);
        }
}

static lv_obj_t *logo_sip_rec_btn_create(void)
{
        lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), logo_obj_id_rec_btn);
        if (obj != NULL)
        {
                return obj;
        }

        obj = lv_label_create(lv_scr_act());
        lv_obj_set_id(obj, logo_obj_id_rec_btn);
        lv_obj_set_pos(obj, 600, 100);
        lv_obj_set_size(obj, 100, 100);
        lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
        /*
         * @日期: 2022-08-20
         * @作者: leo.liu
         * @注释: 设置风格
         */
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFFFFFF), LV_STATE_DEFAULT);
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFF00000), LV_STATE_USER_1);
        lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, LV_STATE_DEFAULT);

        lv_label_set_text(obj, "record");
        lv_obj_set_style_text_color(obj, lv_color_hex(0x00), LV_STATE_DEFAULT);
        lv_obj_set_style_text_align(obj, LV_TEXT_ALIGN_CENTER, LV_STATE_DEFAULT);

        lv_obj_add_event_cb(obj, logo_sip_record_btn_click, LV_EVENT_CLICKED, NULL);
        return obj;
}
static void logo_sip_search_btn_click(lv_event_t *e)
{
        sat_ipcamera_user_password_set(0xFF, "admin", "sat12345678");
        sat_ipcamera_device_online_search();
}
static lv_obj_t *logo_search_btn_create(void)
{
        lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), logo_obj_id_search_btn);
        if (obj != NULL)
        {
                return obj;
        }

        obj = lv_label_create(lv_scr_act());
        lv_obj_set_id(obj, logo_obj_id_search_btn);
        lv_obj_set_pos(obj, 750, 100);
        lv_obj_set_size(obj, 100, 100);
        lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
        /*
         * @日期: 2022-08-20
         * @作者: leo.liu
         * @注释: 设置风格
         */
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFFFFFF), LV_STATE_DEFAULT);
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFF00000), LV_STATE_USER_1);
        lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, LV_STATE_DEFAULT);

        lv_label_set_text(obj, "search");
        lv_obj_set_style_text_color(obj, lv_color_hex(0x00), LV_STATE_DEFAULT);
        lv_obj_set_style_text_align(obj, LV_TEXT_ALIGN_CENTER, LV_STATE_DEFAULT);

        lv_obj_add_event_cb(obj, logo_sip_search_btn_click, LV_EVENT_CLICKED, NULL);
        return obj;
}

static void logo_sip_stop_ipc_btn_click(lv_event_t *e)
{
        sat_linphone_ipcamera_stop();
}
static lv_obj_t *logo_stop_ipc_btn_create(void)
{
        lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), logo_obj_id_stop_ipc_btn);
        if (obj != NULL)
        {
                return obj;
        }

        obj = lv_label_create(lv_scr_act());
        lv_obj_set_id(obj, logo_obj_id_stop_ipc_btn);
        lv_obj_set_pos(obj, 900, 100);
        lv_obj_set_size(obj, 100, 100);
        lv_obj_add_flag(obj, LV_OBJ_FLAG_CLICKABLE);
        /*
         * @日期: 2022-08-20
         * @作者: leo.liu
         * @注释: 设置风格
         */
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFFFFFF), LV_STATE_DEFAULT);
        lv_obj_set_style_bg_color(obj, lv_color_hex(0xFF00000), LV_STATE_USER_1);
        lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, LV_STATE_DEFAULT);

        lv_label_set_text(obj, "stop ipc");
        lv_obj_set_style_text_color(obj, lv_color_hex(0x00), LV_STATE_DEFAULT);
        lv_obj_set_style_text_align(obj, LV_TEXT_ALIGN_CENTER, LV_STATE_DEFAULT);

        lv_obj_add_event_cb(obj, logo_sip_stop_ipc_btn_click, LV_EVENT_CLICKED, NULL);
        return obj;
}
static void logo_rec_state_siaplay(bool ready)
{
        lv_obj_t *obj = logo_sip_rec_btn_create();
        if (ready)
        {
                lv_obj_add_state(obj, LV_STATE_USER_1);
        }
        else
        {
                lv_obj_clear_state(obj, LV_STATE_USER_1);
        }
}
static lv_obj_t *ipcamera_lable_create(void)
{
        lv_obj_t *obj = lv_obj_get_child_form_id(lv_scr_act(), logo_obj_id_ipcamera_info_lable);
        if (obj != NULL)
        {
                return obj;
        }
        obj = lv_label_create(lv_scr_act());
        lv_obj_set_id(obj, logo_obj_id_ipcamera_info_lable);
        lv_obj_set_pos(obj, 0, 200);
        lv_obj_set_size(obj, 1024, 400);

        lv_label_set_long_mode(obj, LV_LABEL_LONG_SCROLL_CIRCULAR);
        lv_obj_set_style_text_color(obj, lv_color_hex(0xFFFFFF), LV_STATE_DEFAULT);
        return obj;
}
static void ipcamera_info_display(void)
{
        lv_obj_t *obj = ipcamera_lable_create();

        int online_num = sat_ipcamera_online_num_get();
        //     int valid_num = sat_ipcamera_valid_num_get();
        char text[1024] = {0};
        for (int i = 0; i < online_num; i++)
        {
                /****************************************************************
                2022-09-21 author:leo.liu 说明:ip
                *****************************************************************/
                strcat(text, sat_ipcamera_ipaddr_get(i));
                /****************************************************************
                2022-09-21 author:leo.liu 说明:user
                *****************************************************************/
                strcat(text, "   ");
                strcat(text, sat_ipcamera_username_get(i));
                /****************************************************************
                2022-09-21 author:leo.liu 说明:密码
                *****************************************************************/
                strcat(text, "   ");
                strcat(text, sat_ipcamera_password_get(i));
                /****************************************************************
                2022-09-21 author:leo.liu 说明:url
                *****************************************************************/
                for (int j = 0; j < sat_ipcamera_profile_token_num_get(i); j++)
                {
                        strcat(text, "   ");
                        strcat(text, sat_ipcamera_rtsp_addr_get(i, j));
                        if (j == 0)
                        {
                                sat_linphone_ipcamera_start(sat_ipcamera_rtsp_addr_get(i, j), sat_ipcamera_username_get(i), sat_ipcamera_password_get(i));
                        }
                }
                strcat(text, "\n\n");
        }
        lv_label_set_text(obj, text);
}

static void logo_ipcamera_state_display(unsigned int type, unsigned int num)
{
        printf("%d,%d\n", type, num);
        if ((type == 1) && (num > 0))
        {
                sat_ipcamera_rtsp_url_get();
        }
        else if ((type == 2) && (num > 0))
        {
                ipcamera_info_display();
        }
}

static void sat_layout_enter(logo)
{
        LV_LOG_USER("enter logo layout ");
     //  sat_linphone_register("leo_id1@sip.linphone.org", "12345", "sip.linphone.org");
  	 sat_linphone_register("7101011234@192.168.170.2",NULL, "192.168.170.2");

        lv_disp_set_bg_opa(lv_disp_get_default(), LV_OPA_TRANSP);
        lv_obj_set_style_bg_opa(lv_scr_act(), LV_OPA_TRANSP, LV_STATE_DEFAULT);
        logo_sip_call_btn_create();
        logo_sip_answer_btn_create();
        logo_sip_snap_btn_create();
        logo_sip_rec_btn_create();
        logo_search_btn_create();
        logo_stop_ipc_btn_create();
        snapshot_state_callback_register(logo_snap_state_display);
        record_state_callback_register(logo_rec_state_siaplay);
        ipcamera_state_callback_register(logo_ipcamera_state_display);

#if 0
        char ipc_grop[8][20];
        int num = 0;
        char rtsp_url[128] = {0};
        char profile_token[8][64] = {0};
        int profile_num = 0;
        ipc_camera_search(ipc_grop, &num);
        ipc_profile_token_get(ipc_grop[0], -1, "admin", "sat12345678", profile_token, &profile_num);
        ipc_camera_rtsp_get(ipc_grop[0], -1, "admin", "sat12345678", profile_token[0], rtsp_url, sizeof(rtsp_url));
#endif
}
static void sat_layout_quit(logo) {}
sat_layout_create(logo);