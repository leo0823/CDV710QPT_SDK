#ifndef _USER_MONITOR_H_
#define _USER_MONITOR_H_
typedef enum
{
	MON_CH_NONE = 0x00,
	MON_CH_DOOR1,
	MON_CH_DOOR2,
	MON_CH_CCTV1,
	MON_CH_CCTV2,
	MON_CH_INTERCOM,
	MON_CH_TOTAL
} MON_CH;
/***
** 日期: 2022-05-12 11:33
** 作者: leo.liu
** 函数作用：获取监控通道
** 返回参数说明：
***/
MON_CH monitor_channel_get(void);

#endif