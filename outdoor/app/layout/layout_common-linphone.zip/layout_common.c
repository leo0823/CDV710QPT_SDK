#include "layout_define.h"
#define RESOURCE_FILE_PATH_MAX 128
/*
 * @日期: 2022-08-08
 * @作者: leo.liu
 * @注释: 获取资源路径
 */
#define RESOURCE_UI_PATH "A:/mnt/ssd20x/project/layout/resource/ui/"
#define RESOURCE_WALLPAPER_PATH "A:/mnt/ssd20x/project/layout/resource/wallpaper/"
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 获取唯一的字符串
 * @return:
 */
static char *resource_src_get(const char *path, const char *file, int w, int h, bool alloc)
{
    int file_length = 0;
    if (path != NULL)
    {
        file_length += strlen(path);
    }
    if (file != NULL)
    {
        file_length += strlen(file);
    }

    if (file_length > RESOURCE_FILE_PATH_MAX)
    {
        LV_LOG_ERROR("recource path length too long");
        return NULL;
    }
    int resouce_string_size = file_length + 1 + sizeof(uint32_t) * 2 + 1;

    char *resource_string = NULL;
    if (alloc == false)
    {
        static char string[RESOURCE_FILE_PATH_MAX] = {0};
        resource_string = string;
    }
    else
    {
        resource_string = lv_mem_alloc(resouce_string_size);
    }
    lv_memset_00(resource_string, resouce_string_size);
    if (path != NULL)
    {
        strcpy(resource_string, path);
    }
    if (file != NULL)
    {
        strcat(resource_string, file);
    }
    uint32_t *p_param = (uint32_t *)&resource_string[strlen(resource_string) + 2];
    *p_param = w;
    p_param++;
    *p_param = h;
    return resource_string;
}
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 获取ui资源的路径
 * @return:
 */
void *resource_ui_src_get(char *file, uint32_t w, uint32_t h)
{
    return (void *)resource_src_get(RESOURCE_UI_PATH, file, w, h, false);
}
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 获取背景图片
 * @return:
 */
void *resource_wallpaper_src_get(char *file, uint32_t w, uint32_t h)
{
    return (void *)resource_src_get(RESOURCE_WALLPAPER_PATH, file, w, h, false);
}
/*
 * @日期: 2022-08-12
 * @作者: leo.liu
 * @功能: 文件路径获取
 * @return:
 */
void *file_path_src_get(char *path, const char *file, uint32_t w, uint32_t h)
{
    return (void *)resource_src_get(path, file, w, h, false);
}
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 释放文件
 * @return:
 */
bool resouce_file_src_free(void *pstr)
{
    if (pstr == NULL)
    {
        return false;
    }
    lv_mem_free(pstr);
    return true;
}
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 创建一个ui资源文件
 * @return:
 */
void *resource_ui_src_alloc(char *file, uint32_t w, uint32_t h)
{
    return (void *)resource_src_get(RESOURCE_UI_PATH, file, w, h, true);
}
/*
 * @日期: 2022-08-11
 * @作者: leo.liu
 * @功能: 创建一个壁纸资源文件
 * @return:
 */
void *resource_wallpaper_src_alloc(char *file, uint32_t w, uint32_t h)
{
    return (void *)resource_src_get(RESOURCE_WALLPAPER_PATH, file, w, h, true);
}
